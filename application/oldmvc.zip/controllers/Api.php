<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	function __construct() {
		parent::__construct();

		$this->load->model('general_model');
		$this->load->library('form_validation');
		$this->load->library('session');
		$this->load->helper("url");
		$this->load->library('encryption');
		$this->load->library('pagination');
		$this->load->helper('date');
		
	}

	public function index()
	{
		$this->load->view('welcome_message');
	}

	// 1. Customer Login
	public function login(){
		$obj = array();
		$userName = $_POST['phone'];
    $userPassword = $_POST['password'];
    $customerDevice = $_POST['customerDevice'];
    $customerDeviceToken = $_POST['customerDeviceToken'];
    $user_record =$this->general_model->check_customer_login($userName,$userPassword);
    if($user_record == false){
			// throw invalid email id or password error
			$obj['status'] = 0;
      $obj['message'] = 'Invalid Login or Password';
		}else{
			$data = array(
				'customerDevice'			=> $customerDevice,
				'customerDeviceToken'	=> $customerDeviceToken
			);
			$where = array('customerId'	=> $user_record['customerId']);
			$this->general_model->update('mst_customers',$data,$where);

			$obj['customerId'] = $user_record['customerId'];
			$obj['customerName'] = $user_record['customerName'];
			$obj['customerPhone'] = $user_record['customerPhone'];
			$obj['customerEmail'] = $user_record['customerEmail'];
			$obj['status'] = 1;
      $obj['message'] = 'Success';
		}

		echo json_encode($obj);
	}

	// 2. Customer Registration
	public function register(){
		$this->form_validation->set_rules('name','Name','required');
		$this->form_validation->set_rules('phone','Phone','required|numeric|is_unique[mst_customers.customerPhone]');
		$this->form_validation->set_rules('email','Email','required|valid_email|is_unique[mst_customers.customerEmail]');
		$this->form_validation->set_rules('password','Password','required');

		if ($this->form_validation->run() == FALSE) {	
			$obj['status'] = 0;
    	$obj['message'] = validation_errors();
		}else{
			$obj = array();
			$customerName = $_POST['name'];
	    $customerPhone = $_POST['phone'];
	    $customerEmail = $_POST['email'];
	    $customerPassword = md5($_POST['password']);

	    $data = array(
	    	'customerName'			=> $customerName,
	    	'customerPhone'			=> $customerPhone,
	    	'customerEmail'			=> $customerEmail,
	    	'customerPassword'	=> $customerPassword,
	    	'customerRegDate'		=> date('Y-m-d H:i:s'),
	    	'isOTPVerified'			=> 1,
	    	'isActive'					=> 1
	    );

	    $customerId=$this->general_model->insert('mst_customers',$data);

	    $otp = rand(1000,9999);
	    $where = array(
		    'customerId'    =>  $customerId
			);
			$data = array(
	      'customerOTP'             => $otp,
	      'customerOTPGenTime'      => date('Y-m-d H:i:s'),
	      'isOTPVerified'           => 0
	    );
		  $this->general_model->update('mst_customers', $data, $where);

		  // Send OTP in SMS
	    $apiKey = "38e906fa-6b13-4595-bf81-9effd6c442d8";
	    $clientID = "a33f172b-55c4-47da-871f-7a2ec88e6422";
	    $mesage = "Your request to reset the password for Bakery app need an OTP. Your OTP is :".$otp;
	    
		  $data = array(
        'apikey'        => $apiKey,
        'clientid'      => $clientID,
        'msisdn'        => $phone,
        'sid'           => "FOODOY",
        'msg'           => $mesage,
        'fl'            =>"0",
        'gwid'          => 2
      );
      list($header,$content) =$this->PostRequest("http://sms.nettyfish.com/vendorsms/pushsms.aspx",$data);

	    $obj['customerId'] = $customerId;
			$obj['customerName'] = $customerName;
			$obj['status'] = 1;
	    $obj['message'] = 'Succesfully Registered';
		}
		echo json_encode($obj);
	}
	
	// 3. Customer Forgot Password
	public function forgotpassword(){
	  $obj = array();
		$phone = $_POST['phone'];
		
		$otp = rand(1000,9999);
		$where = array(
		    'customerPhone'    =>  $phone
		);
		
		$customerCount = $this->general_model->getCount('mst_customers',$where);
		if($customerCount > 0){
	    $data = array(
	      'customerOTP'             => $otp,
	      'customerOTPGenTime'      => date('Y-m-d H:i:s'),
	      'isOTPVerified'           => 0
	    );
		  $this->general_model->update('mst_customers', $data, $where);
		    
	    // Send OTP in SMS
	    $apiKey = "38e906fa-6b13-4595-bf81-9effd6c442d8";
	    $clientID = "a33f172b-55c4-47da-871f-7a2ec88e6422";
	    $mesage = "Your request to reset the password for Bakery app need an OTP. Your OTP is :".$otp;
	    
		  $data = array(
        'apikey'        => $apiKey,
        'clientid'      => $clientID,
        'msisdn'        => $phone,
        'sid'           => "FOODOY",
        'msg'           => $mesage,
        'fl'            =>"0",
        'gwid'          => 2
      );
      list($header,$content) =$this->PostRequest("http://sms.nettyfish.com/vendorsms/pushsms.aspx",$data);
      //echo $content;
		    
		  $obj['status'] = 1;
	    $obj['message'] = 'OTP Sent to given phone number';
		}else{
		  $obj['status'] = 0;
	    $obj['message'] = 'No Customer Registered with given Phone Number';
		}
		echo json_encode($obj);
	}
	
	// 4. Customer OTP verification
	public function verifyOtp(){
	  $obj = array();
		$phone = $_POST['phone'];
		$otp = $_POST['otp'];
		
		$where = array(
	    'customerPhone'                             => $phone,
	    'customerOTP'                               => $otp,
	    'isOTPVerified'                             => 0,
	    'TIMEDIFF(now(), customerOTPGenTime) <='	=> '00:10:00'
		);
		
		$customerCount = $this->general_model->getCount('mst_customers',$where);
		$customers = $this->general_model->get('mst_customers',$where);
		if($customerCount > 0){
	    $dataUpdate = array(
	      'isOTPVerified'  => 1
	    );
		    
		  $this->general_model->update('mst_customers', $dataUpdate, $where);
		  $obj['customerId'] = $customers[0]['customerId'];
		  $obj['status'] = 1;
	    $obj['message'] = 'OTP Verified Successfully';
		}else{
		  $obj['status'] = 0;
	    $obj['message'] = 'Wrong OTP';
		}
		echo json_encode($obj);
	}
	
	// 5. Customer Reset Password
	public function resetPassword(){
	  $obj = array();
		$customerId = $_POST['customerId'];
		$password = $_POST['password'];
		
		$data = array(
		  'customerPassword'    => md5($password)
		);
		
		$where = array(
		  'customerId'        => $customerId 
		);
		
		$this->general_model->update('mst_customers', $data, $where);
		
		$obj['status'] = 1;
	  $obj['message'] = 'Password Updated Successfully';
	     
	  echo json_encode($obj);
	}
	

	function PostRequest($url, $_data) {
    // convert variables array to string:
    $data = array(); 
    while(list($n,$v) = each($_data))
    {
        $data[] = "$n=$v";
    }
    $data = implode('&', $data);
    // format --> test1=a&test2=b etc.
    // parse the given URL
    $url = parse_url($url);
    if ($url['scheme'] != 'http') {
        die('Only HTTP request are supported !');
    }
    // extract host and path:
    $host = $url['host'];
    $path = $url['path'];
    // open a socket connection on port 80
    $fp = fsockopen($host, 80);
    // send the request headers:
    fputs($fp, "POST $path HTTP/1.1\r\n");
    fputs($fp, "Host: $host\r\n");
    fputs($fp, "Content-type: application/x-www-form-urlencoded\r\n");
    fputs($fp, "Content-length: ". strlen($data) ."\r\n");
    fputs($fp, "Connection: close\r\n\r\n");
    fputs($fp, $data);
    $result = '';
    while(!feof($fp)) {
        // receive the results of the request
        $result .= fgets($fp, 128);
    }
    // close the socket connection:
    fclose($fp);
    // split the result header from the content
    $result = explode("\r\n\r\n", $result, 2);
    $header = isset($result[0]) ? $result[0] : '';
    $content = isset($result[1]) ? $result[1] : '';
    // return as array:
    return array($header, $content);
  }

  // 06. Banners
  public function banners(){
  	$obj = array();
  	$where = array(
  		'mst_banners.isActive'	=> 1,
  		'mst_banners.isDeleted'	=> 0,
  	);
  	$banners = $this->general_model->get('mst_banners', $where);
  	if(isset($banners) && is_array($banners)){
			$i=0;
			foreach($banners as $banner){
				if($i > 5){
					break;
				}
				$obj['results'][$i]['bannerID'] = $banner['bannerID'];
				$obj['results'][$i]['bannerName'] = $banner['bannerName'];
				$obj['results'][$i]['bannerLink'] = $banner['bannerLink'];
				$obj['results'][$i]['bannerImage'] = base_url().'uploads/banners/'.$banner['bannerImage'];
				$i++;
			}
			$obj['status'] = 1;
      $obj['message'] = "";
		}else{
			$obj['status'] = 0;
      $obj['message'] = "No Banners";
		}
		echo json_encode($obj);
  }

  // 07. Item Categories
	public function itemCategories(){
	  $obj = array();
    $where = array(
        'isActive'  => 1,
        'isDeleted' => 0
   	);
	   
	  $itemCategories = $this->general_model->get('mst_item_categories', $where);
	   
	  if(isset($itemCategories) && is_array($itemCategories)){
			$i=0;
			foreach($itemCategories as $itemCategory){
		    $whereCount = array(
	        'itemCategory'      =>   $itemCategory['itemCategoryId'],
	        'isActive'          =>   1
		    );
		    $itemCount = $this->general_model->getCount('mst_items', $whereCount);
		    if($itemCount > 0){
	        $obj['results'][$i]['itemCategoryId'] = $itemCategory['itemCategoryId'];
			    $obj['results'][$i]['itemCategoryName'] = $itemCategory['itemCategoryName'];
			    $obj['results'][$i]['itemCategoryImage'] = base_url().'uploads/itemcategories/'.$itemCategory['itemCategoryImage'];
			    $obj['results'][$i]['itemCount'] = $itemCount;
			    $i++;
		    }
			}
			$obj['status'] = 1;
      $obj['message'] = "";
	   }else{
	    $obj['status'] = 0;
      $obj['message'] = "No Categories Found";
	   }
	   echo json_encode($obj);
	}

  // 08. Offers
	public function offers(){
		$obj = array();
		$where = array(
			'isOfferActivated'	=> 1,
			'isDeleted'					=> 0,
			'isActive'					=> 1
		);
		$offers = $this->general_model->get('mst_items', $where);
		if(isset($offers) && is_array($offers)){
			$i=0;
			foreach($offers as $offer){
				if($i > 5){
					break;
				}
				$obj['results'][$i]['itemId'] = $offer['itemId'];
				$obj['results'][$i]['itemName'] = $offer['itemName'];
				$obj['results'][$i]['itemOfferPrice'] = $offer['itemOfferPrice'];
				$obj['results'][$i]['itemImage'] = base_url().'uploads/items/'.$offer['itemImage'];
				$i++;
			}
			$obj['status'] = 1;
      $obj['message'] = "";
		}else{
			$obj['status'] = 0;
      $obj['message'] = "No Offers";
		}
		echo json_encode($obj);
	}

	// 09. Item List
	public function itemList(){
		$obj = array();
		$currentTime = date('H:i:s');

		if(isset($_POST['itemCategory']) && $_POST['itemCategory'] != 0){
      $where = array(
				'mst_items.isDeleted' 		=> 0, 
				'mst_items.isActive' 			=> 1, 
				'mst_items.itemCategory'  => $_POST['itemCategory']
			);
    }else{
      $where = array(
				'mst_items.isDeleted' 	=> 0, 
				'mst_items.isActive' 		=> 1, 
			);
    }

		$items = $this->general_model->get_items($where);
		if(isset($items) && is_array($items)){
			$i=0;
			foreach($items as $item){
				$whereVariants = array(
					'mst_item_variants.itemId'		=> $item['itemId'],
					'mst_item_variants.isActive'	=> 1,
					'mst_item_variants.isDeleted'	=> 0
				);
				$itemVariants = $this->general_model->get_item_variants($whereVariants);
				if(!is_array($itemVariants)){
					continue;
				}
				$obj['results'][$i]['itemId'] = $item['itemId'];
				$obj['results'][$i]['itemName'] = $item['itemName'];
				$obj['results'][$i]['itemDescription'] = $item['itemDescription'];
				$obj['results'][$i]['itemOfferPrice'] = $item['itemOfferPrice'];
				$obj['results'][$i]['itemDisplayPrice'] = $item['itemDisplayPrice'];
				$obj['results'][$i]['itemCategoryId'] = $item['itemCategoryId'];
				$obj['results'][$i]['itemCategory'] = $item['itemCategoryName'];
				$obj['results'][$i]['itemThumb'] = base_url().'uploads/items/'.$item['itemThumb'];
				$obj['results'][$i]['itemImage'] = base_url().'uploads/items/'.$item['itemImage'];

				$i++;
			}
			$obj['status'] = 1;
      $obj['message'] = "";
		}else{
			$obj['status'] = 0;
      $obj['message'] = "No Items";
		}
		echo json_encode($obj);
	}
	
	// 10. Item List with Pagination
	public function itemListPagination(){
		$obj = array();
		$itemCategory = $_POST['itemCategory'];

    if(isset($_POST['itemCategory']) && $_POST['itemCategory'] != 0){
      $where = array(
				'mst_items.isDeleted' 		=> 0, 
				'mst_items.isActive' 			=> 1, 
				'mst_items.itemCategory'  => $itemCategory
			);
    }else{
      $where = array(
				'mst_items.isDeleted' 	=> 0, 
				'mst_items.isActive' 		=> 1, 
			);
    }


		// Pagination 
		$page = ($this->uri->segment(3))? $this->uri->segment(3) : 0;
		
		$config['base_url'] 	=	base_url()."api/itemListPagination/";
		$config['per_page']	=  5;
		$offset = ($page-1) * $config['per_page'];		
		$config['uri_segment'] = 3;		
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['first_link'] = 'First';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li><a href="#">';
		$config['cur_tag_close'] = '</a></li>';
		
		$config['total_rows'] = $this->general_model->get_itemsCount($where);
		$items = $this->general_model->get_items($where,$config['per_page'],$page);
		$itemCount = $config['total_rows'];
		$this->pagination->initialize($config);

		if(isset($items) && is_array($items)){
			$i=0;
			foreach($items as $item){
				$whereVariants = array(
					'mst_item_variants.itemId'		=> $item['itemId'],
					'mst_item_variants.isActive'	=> 1,
					'mst_item_variants.isDeleted'	=> 0
				);
				$itemVariants = $this->general_model->get_item_variants($whereVariants);
				if(!is_array($itemVariants)){
					continue;
				}
				$obj['results'][$i]['itemId'] = $item['itemId'];
				$obj['results'][$i]['itemName'] = $item['itemName'];
				$obj['results'][$i]['itemDescription'] = $item['itemDescription'];
				$obj['results'][$i]['itemOfferPrice'] = $item['itemOfferPrice'];
				$obj['results'][$i]['itemDisplayPrice'] = $item['itemDisplayPrice'];
				$obj['results'][$i]['itemCategoryId'] = $item['itemCategoryId'];
				$obj['results'][$i]['itemCategory'] = $item['itemCategoryName'];
				$obj['results'][$i]['itemThumb'] = base_url().'uploads/items/'.$item['itemThumb'];
				$obj['results'][$i]['itemImage'] = base_url().'uploads/items/'.$item['itemImage'];
				
				$i++;
			}
			$obj['status'] = 1;
      $obj['message'] = "";
      if($page == 0){
                
      }else{
        $obj['previous'] = $page - $config['per_page'];
      }
      
      $obj['next'] = $page + $config['per_page'];
      $obj['totalItem'] = $itemCount;
		}else{
			$obj['status'] = 0;
      $obj['message'] = "No Items";
		}
		echo json_encode($obj);
	}
	
	// 11. Item Details
	public function itemDetails(){
		$obj = array();
		$itemId = $_POST['itemId'];
		$where = array(
			'mst_items.itemId'		=> $itemId,
			'mst_items.isActive'	=> 1,
			'mst_items.isDeleted'	=> 0
		);
		$itemDetails = $this->general_model->get_items($where);

		$whereVariants = array(
			'mst_item_variants.itemId'		=> $itemId,
			'mst_item_variants.isActive'	=> 1,
			'mst_item_variants.isDeleted'	=> 0
		);
		$itemVariants = $this->general_model->get_item_variants($whereVariants);

		$obj['itemId'] = $itemDetails[0]['itemId'];
		$obj['itemName'] = $itemDetails[0]['itemName'];
		$obj['itemDescription'] = $itemDetails[0]['itemDescription'];
		$obj['itemDisplayPrice'] = $itemDetails[0]['itemDisplayPrice'];
		$obj['itemCategoryID'] = $itemDetails[0]['itemCategory'];
		$obj['itemCategoryName'] = $itemDetails[0]['itemCategoryName'];
		$obj['itemOfferPrice'] = $itemDetails[0]['itemOfferPrice'];
		$obj['itemImage'] = base_url().'uploads/items/'.$itemDetails[0]['itemImage'];

		if($itemDetails[0]['isOfferActivated'] == 1){
			$obj['itemOfferFlag'] = 1;
		}else{
			$obj['itemOfferFlag'] = 0;
		}
		
		if(is_array($itemVariants)){
			$i=0;
			foreach($itemVariants as $itemVariant){
			  $obj['itemVariants'][$i]['itemVariantId'] = $itemVariant['itemVariantId'];
				$obj['itemVariants'][$i]['itemVariantName'] = $itemVariant['itemVariantName'];
				$obj['itemVariants'][$i]['itemVariantPrice'] = $itemVariant['itemVariantPrice'];
				$obj['itemVariants'][$i]['itemVariantOfferPrice'] = $itemVariant['itemVariantOfferPrice'];
				$obj['itemVariants'][$i]['itemVariantImage'] = base_url().'uploads/items/'.$itemVariant['itemVariantImage'];
				$i++;
			}
		}

		$itemCategory = $itemDetails[0]['itemCategory'];
		$whereRelated = array(
			'itemId !='							=> $itemId,
			'itemCategory'					=> $itemCategory,
			'mst_items.isActive'		=> 1,
			'mst_items.isDeleted'		=> 0
		);
		$relatedItems = $this->general_model->get_items($whereRelated);
		//echo $this->db->last_query();
		if(is_array($relatedItems)){
			$i=0;
			foreach($relatedItems as $relatedItem){
			  $obj['relatedItems'][$i]['itemId'] =$relatedItem['itemId'];
				$obj['relatedItems'][$i]['itemName'] = $relatedItem['itemName'];
				$obj['relatedItems'][$i]['itemThumb'] = base_url().'uploads/items/'.$relatedItem['itemThumb'];
				$obj['relatedItems'][$i]['itemCategoryName'] = $relatedItem['itemCategoryName'];
				$i++;
			}
		}
		echo json_encode($obj);
	}

	// 14. Delivery Address
	public function deliveryAddresses(){
		$obj = array();
		$customer = $_POST['customer'];
		$where = array('customer'	=> $customer);
		$deliveryAddresses = $this->general_model->get('mst_delivery_address', $where);
		if(is_array($deliveryAddresses)){
			$i=0;
			foreach($deliveryAddresses as $deliveryAddress){
				$obj['deliveryAddresses'][$i]['deliveryAddressId'] = $deliveryAddress['deliveryAddressId'];
				$obj['deliveryAddresses'][$i]['deliveryName'] = $deliveryAddress['deliveryName'];
				$obj['deliveryAddresses'][$i]['deliveryAddress'] = $deliveryAddress['deliveryAddress'];
				$obj['deliveryAddresses'][$i]['deliveryAddress2'] = $deliveryAddress['deliveryAddress2'];
				$obj['deliveryAddresses'][$i]['deliveryCity'] = $deliveryAddress['deliveryCity'];
				$obj['deliveryAddresses'][$i]['deliveryState'] = $deliveryAddress['deliveryState'];
				$obj['deliveryAddresses'][$i]['deliveryAddressLat'] = $deliveryAddress['deliveryAddressLat'];
				$obj['deliveryAddresses'][$i]['deliveryAddressLong'] = $deliveryAddress['deliveryAddressLong'];
				
				$obj['deliveryAddresses'][$i]['deliveryAddresslandmark'] = $deliveryAddress['deliveryAddresslandmark'];
				$obj['deliveryAddresses'][$i]['deliveryAddresspincode'] = $deliveryAddress['deliveryAddresspincode'];
				$obj['deliveryAddresses'][$i]['deliveryAddressPhone'] = $deliveryAddress['deliveryAddressPhone'];
				$obj['deliveryAddresses'][$i]['deliveryAddressType'] = $deliveryAddress['deliveryAddressType'];

				$i++;
			}
			$obj['status'] = 1;
            $obj['message'] = "";
		}else{
		    $obj['status'] = 0;
            $obj['message'] = "No Delivery Address";
		}
		echo json_encode($obj);

	}

	// 15. Add Delivery Address
	public function addDeliveryAddress(){
		$obj = array();
		$customer = $_POST['customer'];
		$deliveryName = $_POST['deliveryName'];
		$deliveryAddress = $_POST['address'];
		$deliveryAddress2 = $_POST['address2'];
		$deliveryCity = $_POST['deliveryCity'];
		$deliveryState = $_POST['deliveryState'];
		$deliveryAddresslandmark = $_POST['deliveryAddresslandmark'];
		$deliveryAddresspincode = $_POST['deliveryAddresspincode'];
		$deliveryAddressLat = $_POST['deliveryAddressLat'];
		$deliveryAddressLong = $_POST['deliveryAddressLong'];
		$deliveryAddressPhone = $_POST['deliveryAddressPhone'];
		$deliveryAddressType = $_POST['deliveryAddressType'];

		$data = array(
			'customer'								=> $customer,
			'deliveryName'						=> $deliveryName,
			'deliveryAddress'					=> $deliveryAddress,
			'deliveryAddress2'				=> $deliveryAddress2,
			'deliveryCity'						=> $deliveryCity,
			'deliveryState'						=> $deliveryState,
			'deliveryAddresslocation'	=> $deliveryAddresslocation,
			'deliveryAddresslandmark'	=> $deliveryAddresslandmark,
			'deliveryAddresspincode'	=> $deliveryAddresspincode,
			'deliveryAddressLat'			=> $deliveryAddressLat,
			'deliveryAddressLong'			=> $deliveryAddressLong,
			'deliveryAddressPhone'		=> $deliveryAddressPhone,
			'deliveryAddressType'			=> $deliveryAddressType,
			'isActive'								=> 1,
		);

		$deliveryAddressId = $this->general_model->insert('mst_delivery_address',$data);
		$obj['deliveryAddressId'] = $deliveryAddressId;
		$obj['status'] = 1;
    $obj['message'] = "Delivery Address Added Succesfully";

    echo json_encode($obj);
	}

	// 16. Edit Delivery Address
	public function editDeliveryAddress(){
		$obj = array();
		$deliveryAddressId = $_POST['deliveryAddressId'];
		$deliveryName = $_POST['deliveryName'];
		$deliveryAddress = $_POST['address'];
		$deliveryAddress2 = $_POST['address2'];
		$deliveryCity = $_POST['deliveryCity'];
		$deliveryState = $_POST['deliveryState'];
		$deliveryAddresslandmark = $_POST['deliveryAddresslandmark'];
		$deliveryAddresspincode = $_POST['deliveryAddresspincode'];
		$deliveryAddressLat = $_POST['deliveryAddressLat'];
		$deliveryAddressLong = $_POST['deliveryAddressLong'];
		$deliveryAddressPhone = $_POST['deliveryAddressPhone'];
		$deliveryAddressType = $_POST['deliveryAddressType'];

		$data = array(
			'deliveryName'						=> $deliveryName,
			'deliveryAddress'					=> $deliveryAddress,
			'deliveryAddress2'				=> $deliveryAddress2,
			'deliveryCity'						=> $deliveryCity,
			'deliveryState'						=> $deliveryState,
			'deliveryAddresslocation'	=> $deliveryAddresslocation,
			'deliveryAddresslandmark'	=> $deliveryAddresslandmark,
			'deliveryAddresspincode'	=> $deliveryAddresspincode,
			'deliveryAddressLat'			=> $deliveryAddressLat,
			'deliveryAddressLong'			=> $deliveryAddressLong,
			'deliveryAddressPhone'		=> $deliveryAddressPhone,
			'deliveryAddressType'			=> $deliveryAddressType,
			'isActive'								=> 1,
		);

		$where = array(
			'deliveryAddressId'				=> $deliveryAddressId
		);

		$this->general_model->update('mst_delivery_address',$data,$where);
		$obj['deliveryAddressId'] = $deliveryAddressId;
		$obj['status'] = 1;
    $obj['message'] = "Delivery Address Updated Succesfully";

    echo json_encode($obj);
	}

	// 17. Search Item
	public function search(){
		$obj = array();
		$searchItem = $_POST['searchItem'];

		$where = array(
			'mst_items.isDeleted' 	=> 0, 
			'mst_items.isActive' 		=> 1, 
		);
		$like =  array(
			'mst_items.itemName'	=> $searchItem
		);
		$items = $this->general_model->get_items($where, null, null, null, null, $like);
		if(isset($items) && is_array($items)){
			$i=0;
			foreach($items as $item){
				$obj['results'][$i]['itemId'] = $item['itemId'];
				$obj['results'][$i]['itemName'] = $item['itemName'];
				$obj['results'][$i]['itemDisplayPrice'] = $item['itemDisplayPrice'];
				$obj['results'][$i]['itemCategory'] = $item['itemCategoryName'];
				$obj['results'][$i]['itemImage'] = base_url().'uploads/items/'.$item['itemImage'];
				$i++;
			}
			$obj['status'] = 1;
      $obj['message'] = "";
		}else{
			$obj['status'] = 0;
      $obj['message'] = "No Items";
		}
		echo json_encode($obj);
	}

	// 18. Cart
	public function cart(){
		$obj = array();
		$itemsJson = $_POST['items'];
		
		$items = json_decode($itemsJson);
		//print_r($items);exit;
		$itemTotal = 0;
		//$packingCharge = 20;
		$gst = 0;
		//$deliveryCharge = 50;
		if(isset($items) && is_array($items)){
			foreach($items as $item){
				$itemVariantId = $item->itemVariantId;
				$quantity = $item->quantity;
				$where = array(
					'itemVariantId'	=> $itemVariantId
				);
				$itemVariantDetails = $this->general_model->get_item_variants($where);
				$itemVariantPrice = $itemVariantDetails[0]['itemVariantOfferPrice'];
				$itemtaxSGST = $itemVariantDetails[0]['taxSGST'];
				$itemtaxCGST = $itemVariantDetails[0]['taxSGST'];
				
				$itemTotal += $itemVariantPrice*$quantity;
				$gst += (($itemVariantPrice*($itemtaxSGST+$itemtaxCGST))/100)*$quantity;
			}
		}
	    
		$totalAmount = $itemTotal + $gst;
		$obj['itemTotal'] = number_format($itemTotal,2);
		$obj['gst'] = number_format($gst,2);
		$obj['totalAmount'] = number_format($totalAmount,2);
		$obj['status'] = 1;
    $obj['message'] = "";

    echo json_encode($obj);
	}

	public function test(){
		$items[0]['itemVariantId'] = 1;
		$items[0]['quantity'] = 5;
		$items[1]['itemVariantId'] = 2;
		$items[1]['quantity'] = 3;
		$items[2]['itemVariantId'] = 3;
		$items[2]['quantity'] = 2;

		echo json_encode($items);
	}

	// 19. Place Order
	public function placeOrder(){
		$obj = array();
		$customer = $_POST['customer'];
		$deliveryMode = $_POST['deliveryMode'];
		$deliveryDate = $_POST['deliveryDate'];
		$deliveryTimeSlot = $_POST['deliveryTimeSlot'];
		$deliveryAddress = $_POST['deliveryAddress'];
		//$orderSubTotal = $_POST['orderSubTotal'];
		//$orderGrandTotal = $_POST['orderGrandTotal'];
		//$orderTotalTax = $_POST['orderTotalTax'];
		$packingCharge = 0;
		$itemsJson = $_POST['items'];

		$items = json_decode($itemsJson);

		// Calculate Delivery Charges
		$wherestore = array(
      'storeId'    => 1
    );
    $stores = $this->general_model->get('mst_stores', $wherestore);
    $storeLat = $stores[0]['storeLat'];
    $storeLong = $stores[0]['storeLong'];
    $maxDeliveryLimit = $stores[0]['maxDeliveryLimit'];

    $whereDeliveryAddress = array(
        'deliveryAddressId'    => $deliveryAddress
    );
    $deliveryAddresses = $this->general_model->get('mst_delivery_address', $whereDeliveryAddress);
    $customerLat = $deliveryAddresses[0]['deliveryAddressLat'];
    $customerLong = $deliveryAddresses[0]['deliveryAddressLong'];
    
    $distance = $this->distance($storeLat,$storeLong,$customerLat,$customerLong, "K");
    //echo $distance; exit;
    if($distance > $maxDeliveryLimit){
      $obj['status'] = 0;
  	  $obj['message'] = "Sorry. We can't deliver to this location";
    }else{
	    $where = array(
				'minDistance <='		=> $distance,
				'maxDistance >='		=> $distance,
				'isDeleted'					=> 0
			);
	    
			$charges = $this->general_model->get('mst_delivery_charges', $where);
			if(is_array($charges)){
				$deliveryCharge = $charges[0]['deliveryCharge'];
			}else{
				$deliveryCharge = 0;
			}

			// Calculate Order Sub Total, Total Tax
			$orderSubTotal = 0;
			$orderTotalTax = 0;
			if(isset($items) && is_array($items)){
				foreach($items as $item){
					$itemVariantId = $item->itemVariantId;
					$quantity = $item->quantity;
					$where = array(
						'itemVariantId'	=> $itemVariantId
					);
					$itemVariantDetails = $this->general_model->get_item_variants($where);
					$itemVariantPrice = $itemVariantDetails[0]['itemVariantOfferPrice'];
					$itemtaxSGST = $itemVariantDetails[0]['taxSGST'];
					$itemtaxCGST = $itemVariantDetails[0]['taxSGST'];
					
					$orderSubTotal += $itemVariantPrice*$quantity;
					$orderTotalTax += (($itemVariantPrice*($itemtaxSGST+$itemtaxCGST))/100)*$quantity;
				}
			}

			$orderGrandTotal = $orderSubTotal + $deliveryCharge + $orderTotalTax;

			$orderNumber = $this->general_model->getmax('orderNumber','trn_orders');
			$data = array(
				'orderNumber'				=> $orderNumber,
				'orderDateTime'			=> date('Y-m-d H:i:s'),
				'customer'					=> $customer,
				'deliveryAddress'		=> $deliveryAddress,
				'orderSubTotal'			=> $orderSubTotal,
				'packingCharge'			=> $packingCharge,
				'deliveryCharge'		=> $deliveryCharge,
				'deliveryMode'			=> $deliveryMode,
				'deliveryDate'			=> $deliveryDate,
				'deliveryTimeSlot'	=> $deliveryTimeSlot,
				'orderTotalTax'			=> $orderTotalTax,
				'orderGrandTotal'		=> $orderGrandTotal,
				'orderStatus'				=> 0
			);

			$orderId = $this->general_model->insert('trn_orders', $data);
			
			$dataStatus = array(
		    'orderId'           => $orderId,
		    'status'            => 1,
		    'updatedDateTime'   => date('Y-m-d H:i:s')
			);
			
			$this->general_model->insert('trn_order_status', $dataStatus);

			$notificationContent = "You have received a new Order with order No:".$orderNumber;

			$dataNotifications = array(
				'orderId'								=> $orderId,
				'notificationContent'		=> $notificationContent,
				'notificationDateTime'	=> date('Y-m-d H:i:s'),
				'isRead'								=> 0
			);

			$this->general_model->insert('trn_notifications', $dataNotifications);


			if(isset($items) && is_array($items)){
				foreach($items as $item){
					$itemVariantId = $item->itemVariantId;
					$quantity = $item->quantity;

					$where = array(
						'itemVariantId'	=> $itemVariantId
					);
					$itemVariantDetails = $this->general_model->get_item_variants($where);
					$itemVariantPrice = $itemVariantDetails[0]['itemVariantOfferPrice'];
					$foodtaxSGST = $itemVariantDetails[0]['taxSGST'];
					$foodtaxCGST = $itemVariantDetails[0]['taxSGST'];

					$orderSubTotalSingle = $itemVariantPrice*$quantity;
					$orderDetailSGSTAmount = $orderSubTotal*$foodtaxSGST/100;
					$orderDetailCGSTAmount = $orderSubTotal*$foodtaxCGST/100;
					$orderDetailTotalAmount = $orderSubTotal+$orderDetailSGSTAmount+$orderDetailCGSTAmount;


					$dataDetails = array(
						'orderId'								=> $orderId,
						'itemVariant'						=> $itemVariantId,
						'itemPrice'							=> $itemVariantPrice,
						'quantity'							=> $quantity,
						'orderSubTotal'					=> $orderSubTotalSingle,
						'orderDetailSGSTAmount'	=> $orderDetailSGSTAmount,
						'orderDetailCGSTAmount'	=> $orderDetailCGSTAmount,
						'orderDetailTotalAmount'=> $orderDetailTotalAmount
					);

					$this->general_model->insert('trn_order_details', $dataDetails);
				}
			}

			$obj['orderId'] = $orderId;
			$obj['items'] = $items;
			$obj['orderSubTotal'] = number_format($orderSubTotal,2);
			$obj['orderTotalTax'] = number_format($orderTotalTax,2);
			$obj['deliveryCharge'] = number_format($deliveryCharge,2);
			$obj['orderGrandTotal'] = number_format($orderGrandTotal,2);
			$obj['status'] = 1;
	    $obj['message'] = "";

	    echo json_encode($obj);
	  }
	}

	// 19A. Confirm Order
	public function confirmOrder(){
		$obj = array();
		$orderId = $_POST['orderId'];

		$where = array(
			'trn_orders.orderId'	=> $orderId,
		);
		$data = array(
			'trn_orders.orderStatus'	=> 1
		);

		$this->general_model->update('trn_orders', $data, $where);

		$obj['status'] = 1;
		$obj['orderId'] = $orderId;
    $obj['message'] = "Order Confirmed Succesfully";
		echo json_encode($obj);
	}

	// 20. My Orders
	public function myorders(){
		$obj = array();
		$customer = $_POST['customer'];

		$where = array(
			'trn_orders.customer'					=> $customer,
		);

		$orders = $this->general_model->get_orders($where, null, null, 'trn_orders.orderId','desc');
		if(isset($orders) && is_array($orders)){
			$i=0;
			foreach($orders as $order){
				$obj['results'][$i]['orderId'] = $order['orderId'];
				$obj['results'][$i]['orderNumber'] = $order['orderNumber'];
				$obj['results'][$i]['orderDate'] = date('d-m-Y', strtotime($order['orderDateTime']));
				$obj['results'][$i]['orderGrandTotal']= number_format($order['orderGrandTotal'],2);
				$obj['results'][$i]['status']	= $order['orderStatusName'];
				$i++;
			}
			$obj['status'] = 1;
    	$obj['message'] = "";
		}else{
			$obj['status'] = 0;
    	$obj['message'] = "No Orders";
		}

		echo json_encode($obj);
	}

	// 21. Order Details
	public function orderDetails(){
		$obj = array();
		$orderId = $_POST['orderId'];

		$where = array(
			'trn_orders.orderId'	=> $orderId,
		);

		$orders = $this->general_model->get_orders($where);
		if(isset($orders) && is_array($orders)){
			$obj['results']['orderId'] = $orders[0]['orderId'];
			$obj['results']['orderNumber'] = $orders[0]['orderNumber'];
			$obj['results']['orderDate'] = date('d-m-Y', strtotime($orders[0]['orderDateTime']));
			$obj['results']['orderSubTotal']=number_format($orders[0]['orderSubTotal'],2);
			$obj['results']['deliveryCharge']=number_format($orders[0]['deliveryCharge'],2);
			$obj['results']['orderTotalTax']=number_format($orders[0]['orderTotalTax'],2);
			$obj['results']['orderGrandTotal']=number_format($orders[0]['orderGrandTotal'],2);
			$obj['results']['deliveryDate']=$orders[0]['deliveryDate'];
			$obj['results']['timeSlot']=$orders[0]['timeSlot'];
			$obj['results']['deliveryModeName']=$orders[0]['deliveryModeName'];
			$obj['results']['status']	= $orders[0]['orderStatusName'];
		}
		$whereDetails = array('trn_order_details.orderId' => $orderId);
		$orderDetails = $this->general_model->get_order_details($whereDetails);
		if(isset($orderDetails) && is_array($orderDetails)){
			$i=0;
			foreach($orderDetails as $orderDetail){
				$obj['results']['orderDetails'][$i]['itemName'] = $orderDetail['itemName'];
				$obj['results']['orderDetails'][$i]['itemVariantName'] = $orderDetail['itemVariantName'];
				$obj['results']['orderDetails'][$i]['itemThumb'] = base_url().'uploads/items/'.$orderDetail['itemThumb'];
				$obj['results']['orderDetails'][$i]['itemCategoryName'] = $orderDetail['itemCategoryName'];
				$obj['results']['orderDetails'][$i]['itemPrice'] = $orderDetail['itemPrice'];
				$obj['results']['orderDetails'][$i]['quantity'] = $orderDetail['quantity'];
				$i++;
			}
			$obj['status'] = 1;
    	$obj['message'] = "";
		}else{
			$obj['status'] = 0;
    	$obj['message'] = "No Orders";
		}
		echo json_encode($obj);
	}

	// 22. Cancel Order
	public function cancelOrder(){
		$obj = array();
		$orderId = $_POST['orderId'];

		$where = array('orderId'	=> $orderId);
		$orders = $this->general_model->get('trn_orders',$where);
		if($orders[0]['orderStatus'] == 1){
			$data = array('orderStatus' => 8);
			$this->general_model->update('trn_orders',$data,$where);

			$dataStatus = array(
				'orderId'					=> $orderId,
				'status'					=> 8,
				'updatedDateTime'	=> date('Y-m-d H:i:s')
			);
			$this->general_model->insert('trn_order_status',$dataStatus);

			$obj['status'] = 1;
    	$obj['message'] = "Order Cancelled";
		}else{
			$obj['status'] = 0;
    	$obj['message'] = "Unable to Cancel the Order.";
		}
		echo json_encode($obj);
	}

	// 23. Track Order
	public function trackOrder(){
		$obj = array();
		$orderId = $_POST['orderId'];

		$where = array(
			'orderId'	=> $orderId
		);

		$orderStatusDetails = $this->general_model->get_order_status($where);

		if(isset($orderStatusDetails) && is_array($orderStatusDetails)){
			$i=0;
			foreach($orderStatusDetails as $orderStatusDetail){
				$obj['results'][$i]['orderStatusName'] = $orderStatusDetail['orderStatusName'];
				$obj['results'][$i]['orderStatusDate'] = date('d/m/Y D',strtotime($orderStatusDetail['updatedDateTime']));
				$obj['results'][$i]['orderStatusTime'] = date('H:i A',strtotime($orderStatusDetail['updatedDateTime']));
				$i++;
			}
			$obj['status'] = 1;
    	$obj['message'] = "";
		}else{
			$obj['status'] = 0;
    	$obj['message'] = "No Status";
		}
		echo json_encode($obj);
	}

	// 24. Time Slots
  public function timeslots(){
  	$obj = array();
  	$where = array(
  		'mst_delivery_time_slots.isActive'	=> 1,
  		'mst_delivery_time_slots.isDeleted'	=> 0,
  	);
  	$timeslots = $this->general_model->get('mst_delivery_time_slots', $where);
  	if(isset($timeslots) && is_array($timeslots)){
			$i=0;
			foreach($timeslots as $timeslot){
				if($i > 5){
					break;
				}
				$obj['results'][$i]['deliveryTimeSlotID'] = $timeslot['deliveryTimeSlotID'];
				$obj['results'][$i]['timeSlot'] = $timeslot['timeSlot'];
				$i++;
			}
			$obj['status'] = 1;
      $obj['message'] = "";
		}else{
			$obj['status'] = 0;
      $obj['message'] = "No Timeslots";
		}
		echo json_encode($obj);
  }

  // 25. Delivery Modes
  public function deliverymodes(){
  	$obj = array();
  	$where = array();
  	$deliverymodes = $this->general_model->get('sys_delivery_mode', $where);
  	if(isset($deliverymodes) && is_array($deliverymodes)){
			$i=0;
			foreach($deliverymodes as $deliverymode){
				if($i > 5){
					break;
				}
				$obj['results'][$i]['deliveryModeId'] = $deliverymode['deliveryModeId'];
				$obj['results'][$i]['deliveryModeName'] = $deliverymode['deliveryModeName'];
				$i++;
			}
			$obj['status'] = 1;
      $obj['message'] = "";
		}else{
			$obj['status'] = 0;
      $obj['message'] = "No Delivery Modes";
		}
		echo json_encode($obj);
  }
	
	
	// 26. Delivery Details
	public function deliveryDetails(){
	    $obj = array();
	    $where = array(
	      'isDeleted'   => 0
	    );
	    $whereStore =array('storeId' => 1);
	    $charges = $this->general_model->get('mst_delivery_charges', $where);
	    $storeDetails = $this->general_model->get('mst_stores', $whereStore);
	    if(is_array($charges)){
	        $i=0;
	        foreach($charges as $charge){
	            $obj['results'][$i]['minDistance'] = $charge['minDistance'];
	            $obj['results'][$i]['maxDistance'] = $charge['maxDistance'];
	            $obj['results'][$i]['deliveryCharge'] = $charge['deliveryCharge'];
	            $i++;
	        }
	        $obj['status'] = 1;
    	    $obj['message'] = "Success";
	    }else{
	       $obj['status'] = 1;
	       $obj['message'] = "No Delivery Details";
	    }
	    $obj['customDeliveryMsg'] = $storeDetails[0]['customDeliveryMsg'];
	    $obj['minOrderAmount'] = $storeDetails[0]['minOrderAmount'];
	    echo json_encode($obj);
	}

	// 27. Bakery Delivery Charge (Not Used)
	public function bakeryLocation(){
    $bakery = $_POST['bakery'];
    $deliveryAddress = $_POST['deliveryAddress'];
    $where = array(
        'bakeryId'    => $bakery
    );
    $bakeries = $this->general_model->get('mst_bakeries', $where);
    $bakeryLat = $bakeries[0]['bakeryLat'];
    $bakeryLong = $bakeries[0]['bakeryLong'];
    $maxDeliveryLimit = $bakeries[0]['maxDeliveryLimit'];
    
    $whereDeliveryAddress = array(
        'deliveryAddressId'    => $deliveryAddress
    );
    $deliveryAddresses = $this->general_model->get('mst_delivery_address', $whereDeliveryAddress);
    $customerLat = $deliveryAddresses[0]['deliveryAddressLat'];
    $customerLong = $deliveryAddresses[0]['deliveryAddressLong'];
    
    $distance = $this->distance($bakeryLat,$bakeryLong,$customerLat,$customerLong, "K");
    
    if($distance > $maxDeliveryLimit){
      $obj['status'] = 0;
  	  $obj['message'] = "Sorry. We can't deliver food to this location";
    }else{
    	$where = array(
  			'bakery'						=> $bakery,
  			'minDistance <='		=> $distance,
  			'maxDistance >='		=> $distance,
  			'isDeleted'					=> 0
  		);
      
  		$charges = $this->general_model->get('mst_delivery_charges', $where);
  		if(is_array($charges)){
				$deliveryCharge = $charges[0]['deliveryCharge'];
  		}else{
  			$deliveryCharge = 0;
  		}
      $obj['deliveryCharge'] = $deliveryCharge;
	    $obj['status'] = 1;
    	$obj['message'] = "Success";
	  }
	  echo json_encode($obj);
	}
	
	function distance($lat1, $lon1, $lat2, $lon2, $unit) {

    $theta = $lon1 - $lon2;
    $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
    $dist = acos($dist);
    $dist = rad2deg($dist);
    $miles = $dist * 60 * 1.1515;
    $unit = strtoupper($unit);
  
    if ($unit == "K") {
        return ($miles * 1.609344);
    } else if ($unit == "N") {
        return ($miles * 0.8684);
    } else {
        return $miles;
    }
  }
	
	// 28. Delete Customer
	public function deleteCustomer(){
	    $customerPhone = $_POST['customerPhone'];
	    $obj = array();
	    
	    $where = array('customerPhone'  => $customerPhone);
	    $this->general_model->delete('mst_customers',$where);
	    
	    $obj['status'] = 1;
	    $obj['message'] = "Customer Deleted";
	    
	    echo json_encode($obj);
	}

	// 29. Profile
	public function profile(){
		$obj = array();
		$customerId = $_POST['customerId'];
		$where = array(
			'customerId'	=> $customerId
		);
		$customers = $this->general_model->get('mst_customers',$where);
		if(isset($customers) && is_array($customers)){
			$obj['results']['customerName'] = $customers[0]['customerName'];
			$obj['results']['customerPhone'] = $customers[0]['customerPhone'];
			$obj['results']['customerEmail'] = $customers[0]['customerEmail'];
			$obj['results']['customerGender'] = $customers[0]['customerGender'];
			$obj['results']['customerDOB'] = $customers[0]['customerDOB'];
			$obj['status'] = 1;
    	$obj['message'] = "";
		}else{
			$obj['status'] = 0;
    	$obj['message'] = "No Profile Details";
		}

		echo json_encode($obj);
	}

	// 30. Update Profile
	public function updateProfile(){
		$obj = array();
		$customerId = $_POST['customerId'];
		$customerName = $_POST['customerName'];
		$customerEmail = $_POST['customerEmail'];
		$customerGender = $_POST['customerGender'];
		$customerDOB = $_POST['customerDOB'];

		$data = array(
			'customerName'			=> $customerName,
			'customerEmail'			=> $customerEmail,
			'customerGender'		=> $customerGender,
			'customerDOB'				=> $customerDOB
		);

		$where = array('customerId'	=> $customerId);
		$this->general_model->update('mst_customers', $data, $where);

		$obj['status'] = 1;
    $obj['message'] = "Profile Updated Successfully";

    echo json_encode($obj);
	}

	function createToken($customerId = 0){

		// ***** Generate Token *****
    $char = "bcdfghjkmnpqrstvzBCDFGHJKLMNPQRSTVWXZaeiouyAEIOUY!@#%";
    $token = '';
    for ($i = 0; $i < 47; $i++) $token .= $char[(rand() % strlen($char))];
    $data = array(
    	'customer'		=> $customerId,
    	'token'				=> $token
    );
    $this->general_model->insert('mst_api_tokens',$data);
    return true;
	}


	
	//////////////////////
	// Delivery Boy API //
	/////////////////////
	
	public function deliveryBoyLogin(){
		$obj = array();
		$userName = $_POST['employeeID'];
        $userPassword = $_POST['password'];
        $deliveryBoyDeviceToken = $_POST['deliveryBoyDeviceToken'];
        $user_record =$this->general_model->check_deliveryBoy_login($userName,$userPassword);
        if($user_record == false){
			// throw invalid email id or password error
			$obj['status'] = 0;
            $obj['message'] = 'Invalid Employee ID or Password';
		}else{
		    // Update Device Token
		    $data = array('deliveryBoyDeviceToken'  => $deliveryBoyDeviceToken);
		    $where = array('deliveryBoyID'  => $user_record['deliveryBoyID']);
		    $this->general_model->update('mst_delivery_boys', $data, $where);
		    
			$obj['deliveryBoyID'] = $user_record['deliveryBoyID'];
			$obj['deliveryBoyCode'] = $user_record['deliveryBoyCode'];
			$obj['deliveryBoyName'] = $user_record['deliveryBoyName'];
			$obj['status'] = 1;
            $obj['message'] = 'Success';
		}

		echo json_encode($obj);
	}
	
	public function dbmyorders(){
		$obj = array();
		$deliveryBoyID = $_POST['deliveryBoyID'];

		$where = array(
			'trn_deliveryboy_orders.deliveryBoyID'					=> $deliveryBoyID
		);

		$orders = $this->general_model->get_dborders($where, null, null, 'trn_deliveryboy_orders.deliveryBoyOrderID','desc');
		if(isset($orders) && is_array($orders)){
			$i=0;
			foreach($orders as $order){
				$obj['results'][$i]['orderId'] = $order['orderId'];
				$obj['results'][$i]['orderNumber'] = $order['orderNumber'];
				$obj['results'][$i]['orderDate'] = date('d-m-Y', strtotime($order['orderDateTime']));
				$obj['results'][$i]['restaurantBranch'] = $order['restaurantBranchName'];
				$obj['results'][$i]['customerName'] = $order['customerName'];
				$obj['results'][$i]['customerPhone'] = $order['customerPhone'];
				$obj['results'][$i]['orderGrandTotal']= $order['orderGrandTotal'];
				$obj['results'][$i]['orderStatusName']= $order['orderStatusName'];
				if($order['deliveryBoyOrderStatus'] == 0){
				    $obj['results'][$i]['deliveryBoyOrderStatus']	= "Pending";
				}else if($order['deliveryBoyOrderStatus'] == 1){
				    $obj['results'][$i]['deliveryBoyOrderStatus']	= "Accepted";
				}else if($order['deliveryBoyOrderStatus'] == 2){
				    $obj['results'][$i]['deliveryBoyOrderStatus']	= "Rejected";
				}else{
				    $obj['results'][$i]['deliveryBoyOrderStatus']	= "Delivered";
				}
				
				
				
				$i++;
			}
			$obj['status'] = 1;
    	    $obj['message'] = "";
		}else{
			$obj['status'] = 0;
    	    $obj['message'] = "No Orders";
		}

		echo json_encode($obj);
	}
	
	public function dborderDetails(){
		$obj = array();
		$orderId = $_POST['orderId'];

		$where = array('trn_orders.orderId' => $orderId);
		$whereOrderDetals = array('trn_order_details.orderId' => $orderId);
		
		$orders = $this->general_model->get_dborders($where);
		$orderItemCount = $this->general_model->getCount('trn_order_details', $whereOrderDetals);
		$orderDetails = $this->general_model->get_order_details($whereOrderDetals);
		
		$obj['results']['orderId'] = $orders[0]['orderId'];
		$obj['results']['customerName'] = $orders[0]['customerName'];
		$obj['results']['restaurantBranchName'] = $orders[0]['restaurantBranchName'];
		$obj['results']['restaurantBranchAddress'] = $orders[0]['restaurantBranchAddress'];
		$obj['results']['restaurantBranchLat'] = $orders[0]['restaurantBranchLat'];
		$obj['results']['restaurantBranchLong'] = $orders[0]['restaurantBranchLong'];
		$obj['results']['customerPhone'] = $orders[0]['customerPhone'];
		$obj['results']['deliveryAddress'] = $orders[0]['deliveryAddress'];
		$obj['results']['deliveryAddressLat'] = $orders[0]['deliveryAddressLat'];
		$obj['results']['deliveryAddressLong'] = $orders[0]['deliveryAddressLong'];
		$obj['results']['deliveryAddressPhone'] = $orders[0]['deliveryAddressPhone'];
		$obj['results']['deliveryAddresslocation'] = $orders[0]['deliveryAddresslocation'];
		$obj['results']['deliveryAddresslandmark'] = $orders[0]['deliveryAddresslandmark'];
		$obj['results']['orderNumber'] = $orders[0]['orderNumber'];
		$obj['results']['orderDate'] = date('d-m-Y', strtotime($orders[0]['orderDateTime']));
		$obj['results']['orderTime'] = date('H:i', strtotime($orders[0]['orderDateTime']));
		$obj['results']['orderGrandTotal'] = $orders[0]['orderGrandTotal'];
		$obj['results']['orderItemCount'] = $orderItemCount;
		if($orders[0]['deliveryBoyOrderStatus'] == 0){
		    $obj['results']['deliveryBoyOrderStatus']	= "Pending";
		}else if($orders[0]['deliveryBoyOrderStatus'] == 1){
		    $obj['results']['deliveryBoyOrderStatus']	= "Accepted";
		}else if($orders[0]['deliveryBoyOrderStatus'] == 2){
		    $obj['results']['deliveryBoyOrderStatus']	= "Rejected";
		}else{
		    $obj['results']['deliveryBoyOrderStatus']	= "Delivered";
		}
		
		$obj['status'] = 1;
    	$obj['message'] = "";
    	
		echo json_encode($obj);
	}
	
	public function dbacceptOrder(){
		$obj = array();
		$orderId = $_POST['orderId'];
		
		// Update Status of Delivery Boy Order
		$where = array('orderID'    => $orderId);
		$data = array('status'  => 1);
		$this->general_model->update('trn_deliveryboy_orders', $data, $where);
		
		// Update Order Status in Order Table
		$where2 = array('orderId'    => $orderId);
		$data2 = array('orderStatus'  => 4);
		$this->general_model->update('trn_orders', $data2, $where2);
		
		// Update Order Status in Details Table
		$data3 = array(
		    'orderId'           => $orderId,
		    'status'            => 4,
		    'updatedDateTime'   => date('Y-m-d H:i:s')
		);
		$this->general_model->insert('trn_order_status', $data3);
		
		$obj['status'] = 1;
    	$obj['message'] = "Order Accepted Successfully";
    	
    	echo json_encode($obj);
	}
	
	public function dbrejectOrder(){
		$obj = array();
		$orderId = $_POST['orderId'];
		
		$where = array('orderID'    => $orderId);
		$data = array('status'  => 2);
		
		$this->general_model->update('trn_deliveryboy_orders', $data, $where);
		
		$obj['status'] = 1;
    	$obj['message'] = "Order Rejected Successfully";
    	
    	echo json_encode($obj);
	}
	
	public function dbdeliverOrder(){
		$obj = array();
		$orderId = $_POST['orderId'];
		
		// Update Status of Delivery Boy Order
		$where2 = array('orderID'    => $orderId);
		$data2 = array('status'  => 3);
		$this->general_model->update('trn_deliveryboy_orders', $data2, $where2);
		
		// Update Order Status in Order Table
		$where = array('orderId'    => $orderId);
		$data = array('orderStatus'  => 5);
		$this->general_model->update('trn_orders', $data, $where);
		
		// Update Order Status in Details Table
		$data3 = array(
		    'orderId'           => $orderId,
		    'status'            => 5,
		    'updatedDateTime'   => date('Y-m-d H:i:s')
		);
		$this->general_model->insert('trn_order_status', $data3);
		
		$obj['status'] = 1;
    	$obj['message'] = "Order Delivered Successfully";
    	
    	echo json_encode($obj);
	}
	
	public function dblogout(){
		$obj = array();
		$deliveryBoyID = $_POST['deliveryBoyID'];
		$deliveryBoyDeviceToken = $_POST['deliveryBoyDeviceToken'];
		
		$whereCheck = array('deliveryBoyDeviceToken'  => $deliveryBoyDeviceToken, 'deliveryBoyID'  => $deliveryBoyID);
		$count = $this->general_model->getCount('mst_delivery_boys', $whereCheck);
		
		if($count > 0){
		    $data = array('deliveryBoyDeviceToken'  => '');
		    $where = array('deliveryBoyID'  => $deliveryBoyID);
		    $this->general_model->update('mst_delivery_boys', $data, $where);
		
		    $obj['status'] = 1;
    	    $obj['message'] = "Successfully Logged Out";
		}else{
		    $obj['status'] = 0;
    	    $obj['message'] = "Already Logged Out";
		}
		
    	
    	echo json_encode($obj);
	}
	
	function push_notification_android($device_id,$message,$imageUrl = ""){

        //API URL of FCM
        $url = 'https://fcm.googleapis.com/fcm/send';
    
        /*api_key available in:
        Firebase Console -> Project Settings -> CLOUD MESSAGING -> Server key*/    
        $api_key = 'AIzaSyDELtBR5CrVzWRfTrYcphPp2dYyiYa8SS4';
                 
        $messageFull = array(
          'message'   => "$message",
          'title'     => "Foodoyes",
          'image'     => $imageUrl
        );
    
        // $fields = array (
        //     'registration_ids' => array (
        //       $device_id
        //     ),
        //     'data' => array (
        //       "message" => $messageFull,
        //     )
        // );
    
        $fields = array(
          'to' => $device_id,
          'data' => $messageFull,
        );
    
        //header includes Content type and api key
        $headers = array(
            'Content-Type:application/json',
            'Authorization:key='.$api_key
        );
                    
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
        $result = curl_exec($ch);
        if ($result === FALSE) {
            die('FCM Send Error: ' . curl_error($ch));
        }
        curl_close($ch);
        // echo '<h2>Result</h2><hr/><h3>Request </h3><p><pre>';
        //         echo json_encode($fields,JSON_PRETTY_PRINT);
        //         echo '</pre></p><h3>Response </h3><p><pre>';
        //         echo $result;
        //         echo '</pre></p>';
        //         exit;
        return $result;
      }
	
}
