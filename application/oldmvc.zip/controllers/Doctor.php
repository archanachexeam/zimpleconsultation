<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Doctor extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	function __construct() {
		parent::__construct();

		$this->load->model('general_model');
		$this->load->library('form_validation');
		$this->load->library('session');
		$this->load->helper("url");
		$this->load->library('encryption');
		$this->load->library('pagination');
		$this->load->helper('date');
	}

	public function index(){
		$this->session->set_userdata('site_lang',  "english");
		redirect(base_url().'doctor/login');
	}

	public function login(){

		$data['currentMenu'] = 'Doctor login';
		$data['pageHeading'] = 'Doctor Login';
		$data['pageTitle'] = "Doctor Login | ".HEX_APPLICATION_NAME;

		$data['loginRedirect']=base_url().'Doctor/checklogin';

		$this->load->view('doctor/login/login',$data);
	}

	public function checklogin(){
		$this->form_validation->set_rules('login', 'Username', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');
		
		if ($this->form_validation->run() == FALSE) {	
			//var_dump(validation_errors());
			$this->session->set_flashdata('registerMessage',validation_errors(),':old:');
			$data['loginRedirect']=base_url().'Doctor/checklogin';
			
			redirect(base_url().'Doctor/login');
		}else{
			$userName=$this->input->post('login');
			$userPassword=$this->input->post('password');
			$user_record =$this->general_model->check_doctor_login($userName,$userPassword);
			if($user_record == false){
				// throw invalid email id or password error
				$this->session->set_flashdata('registerMessage','Invalid Login or Password',':old:');
				redirect(base_url().'Doctor/login');
			}else{
				$admindata = array(
					'logged_in'					=> true,
					'user_logged_in' 		=> true,
					'logged_in_type'		=> 'doctor',
					'userId' 						=> $user_record['doctorId'],
					'userName'		    	=> $user_record['doctorFName']." ".$user_record['doctorLName']
				);
				
				$this->session->set_userdata('adminAccess',1);
				$this->session->set_userdata($admindata);
				redirect(base_url().'Doctor/dashboard');

			}
		}

	}

	public function dashboard(){
    if($this->session->userdata('logged_in_type') != "doctor") { redirect(base_url().'Doctor/login');	}
    

		redirect(base_url().'Doctor/bookings');

		$data['currentMenu'] = 'dashboard';
		$data['pageHeading'] = 'Dashboard';
		$data['pageTitle'] = "Doctor Dashboard | ".HEX_APPLICATION_NAME;

		$this->load->view('admin/templates/header',$data);
		$this->load->view('doctor/dashboard/dashboard',$data);
		$this->load->view('admin/templates/footer');
	}

	public function logout() {		
		$this->session->sess_destroy();
		session_start();
		session_destroy();
		redirect(base_url().'Doctor/login');
	}	

	public function bookings(){
		if($this->session->userdata('logged_in_type') != "doctor") { redirect(base_url().'Doctor/login');	}

		$doctorId = $this->session->userdata('userId');
		
		if(isset($_POST['consultationDate'])){
			$consultationDate = date('Y-m-d',strtotime(str_replace('/','-',$this->input->post('consultationDate'))));
		}else{
			$consultationDate = date('Y-m-d');
		}

		$where = array(
			'trn_bookings.doctor'						=> $doctorId,
			'trn_bookings.consultationDate'	=> $consultationDate,
			'trn_bookings.isCancelled' 			=> 0
		);
		$data['bookings'] =$this->general_model->get_bookings($where);
		$data['consultationDate'] = $consultationDate;

		$data['currentMenu'] = 'Bookings';
		$data['pageHeading'] = 'Bookings';
		$data['singleHeading'] = 'Bookings';
		$data['pageTitle'] = "Bookings | ".HEX_APPLICATION_NAME;

		$data['loginRedirect']=base_url().'Doctor/bookings';

		$this->load->view('admin/templates/header',$data);
		$this->load->view('doctor/bookings/bookings',$data);
		$this->load->view('admin/templates/footer');
	}

	public function consultation($bookingId = 0){
		if($this->session->userdata('logged_in_type') != "doctor") { redirect(base_url().'doctor/login');	}

		$doctorId = $this->session->userdata('userId');

		$whereSingleCategory = array('trn_bookings.bookingId' => $bookingId);
		$data['singleBooking'] = $this->general_model->get_bookings($whereSingleCategory);

		$patient = $data['singleBooking'][0]['patient'];
		$doctor = $doctorId;

		$wherePVme = array(
			'trn_bookings.patient'							=> $patient,
			'trn_bookings.doctor'								=> $doctor,
			'trn_bookings.bookingId !='					=> $bookingId,
			'trn_bookings.consultationDate <'		=> date('Y-m-d'),
			'trn_bookings.bookingStatus'				=> 5
		);

		$data['pvSameDrList'] = $this->general_model->get_bookings($wherePVme);

		$wherePVOth = array(
			'trn_bookings.patient'							=> $patient,
			'trn_bookings.doctor !='						=> $doctor,
			'trn_bookings.bookingId !='					=> $bookingId,
			'trn_bookings.consultationDate <'		=> date('Y-m-d'),
			'trn_bookings.bookingStatus'				=> 5
		);

		$data['pvOthDrList'] = $this->general_model->get_bookings($wherePVOth);

		$data['currentMenu'] = 'Consultation';
		$data['pageHeading'] = 'Consultation';
		$data['singleHeading'] = 'Consultation';
		$data['pageTitle'] = "Consultation | ".HEX_APPLICATION_NAME;

		$data['loginRedirect']=base_url().'Doctor/updateConsultation';

		$this->load->view('admin/templates/header',$data);
		$this->load->view('transactions/bookings/consultation',$data);
		$this->load->view('admin/templates/footer');
	}

	public function updateConsultation(){
		if($this->session->userdata('logged_in_type') != "doctor") { redirect(base_url().'doctor/login');	}

		$this->form_validation->set_rules('bookingId','Booking Id','required|numeric');

		if ($this->form_validation->run() == FALSE) {	
			$this->session->set_flashdata('registerMessage',validation_errors(),':old:');
			redirect(base_url().'Doctor/Bookings');
		}else{
			$data = array(
				'consultationSummary'	=> $this->input->post('consultationSummary'),
				'medicines'						=> $this->input->post('medicines'),
				'labTests'						=> $this->input->post('labTests'),
				'bookingRemarks'			=> $this->input->post('bookingRemarks'),
				'bookingStatus'				=> 5
			);

			$where = array(
				'bookingId'	=> $this->input->post('bookingId')
			);
			$this->general_model->update('trn_bookings',$data, $where);
			$this->session->set_flashdata('registerMessage','Updated Successfully',':old:');
			redirect(base_url().'Doctor/Bookings');
		}
	}

	public function viewbookings($bookingId = 0){
		if($this->session->userdata('logged_in_type') != "doctor") { redirect(base_url().'Doctor/login');	}

		$doctorId = $this->session->userdata('userId');

		$where = array('trn_bookings.bookingId' => $bookingId,);
		$data['singleBooking'] =$this->general_model->get_bookings($where);

		$data['currentMenu'] = 'Bookings';
		$data['pageHeading'] = 'Bookings';
		$data['singleHeading'] = 'Bookings';
		$data['pageTitle'] = "Bookings | ".HEX_APPLICATION_NAME;


		$this->load->view('admin/templates/header',$data);
		$this->load->view('doctor/bookings/viewBooking',$data);
		$this->load->view('admin/templates/footer');
	}

}