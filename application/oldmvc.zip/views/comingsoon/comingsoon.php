<div class="row">
	<div class="col-md-12">
		<div class="col-md-12 col-lg-12">
			<div class="card">
				<div class="card-header">
					<h3 class="card-title"><?php echo $pageHeading;?></h3>
				</div>
				<div class="card-body">
					<center><h1 class="text-primary">Under Development</h1></center>
				</div>
			</div>
		</div>
	</div>
</div>