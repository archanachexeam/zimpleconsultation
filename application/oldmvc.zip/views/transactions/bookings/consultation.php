<div class="row">
	<div class="col-md-12">
		<div class="col-md-12 col-lg-12">
			<div class="card">
				<div class="card-header">
					<h3 class="card-title"><?php echo $singleHeading." : ".$singleBooking[0]['patientOPNumber']." - ".$singleBooking[0]['patientFName']." ".$singleBooking[0]['patientLName'];?></h3>
				</div>
				<div class="card-body">
					<div class="wideget-user">
						<div class="row">
							<div class="col-lg-6 col-md-12">
								<div class="wideget-user-desc d-sm-flex">
									<div class="user-wrap">
										<h4><?php echo $singleHeading." : ".$singleBooking[0]['patientOPNumber']." - ".$singleBooking[0]['patientFName']." ".$singleBooking[0]['patientLName'];?></h4>
										<h5><?php echo "Token Number : ".$singleBooking[0]['tokenNumber'];?></h5>
										<h6 class="text-muted mb-3">Date: <?php echo date('d F Y',strtotime($singleBooking[0]['consultationDate']));?></h6>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="row">
	<div class="col-md-8">
		<div class="col-md-12 col-lg-12">
			<div class="card">
				<div class="card-header">
					<h3 class="card-title">Consultation Details</h3>
				</div>
				<div class="card-body">
					<?php 
	          $attributes = array('class' => 'form form-horizontal form-bordered', 'id' => 'form');
	          echo form_open_multipart($loginRedirect,$attributes);
	        ?>
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label class="form-label">Consultation Summary </label>
								<div class="doctorListOuter">
									<textarea class="form-control consultationSummary" name="consultationSummary" rows="5">
										<?php echo $singleBooking[0]['consultationSummary'];?>
									</textarea>
									<input type="hidden" name="bookingId" value="<?php echo $singleBooking[0]['bookingId'];?>">
								</div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label class="form-label">Medicines </label>
								<div class="doctorListOuter">
									<textarea class="form-control medicines" name="medicines" rows="5">
										<?php echo $singleBooking[0]['medicines'];?>
									</textarea>
								</div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label class="form-label">Lab Tests </label>
								<div class="doctorListOuter">
									<textarea class="form-control labTests" name="labTests" rows="5">
										<?php echo $singleBooking[0]['labTests'];?>
									</textarea>
								</div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label class="form-label">Other Remarks </label>
								<div class="doctorListOuter">
									<textarea class="form-control bookingRemarks" name="bookingRemarks" rows="5">
										<?php echo $singleBooking[0]['bookingRemarks'];?>
									</textarea>
								</div>
							</div>
						</div>
					</div>
	        <div class="row">
						<div class="col-md-4">
							<div class="form-group">
								<div class="form-label"></div>
								<input type="submit" class="btn btn-primary" name="" value="Submit">
							</div>
						</div>
					</div>
	        <?php echo form_close();?>
				</div>
			</div>
		</div>
	</div>
	<div class="col-md-4">
		<div class="col-md-12 col-lg-12">
			<div class="card">
				<div class="card-header">
					<h3 class="card-title">Previous Visits to Me</h3>
				</div>
				<div class="card-body">
					<?php
						if(is_array($pvSameDrList)){
					?>
							<ul class="list-group">
					<?php
							foreach($pvSameDrList as $pvSameDr){
					?>
								<li class="list-group-item">
									<a href="<?php echo base_url()?>transactions/Bookings/view/<?php echo $pvSameDr['bookingId'];?>" class="" title="View" target="_blank">
										<?php echo date('d-m-Y',strtotime($pvSameDr['consultationDate']));?>
									</a>
								</li>
					<?php
							}
					?>
							</ul>
					<?php
						}else{
							echo "No Previous Visits";
						}
					?>
				</div>
			</div>
			<div class="card">
				<div class="card-header">
					<h3 class="card-title">Previous Visits to Others</h3>
				</div>
				<div class="card-body">
					<?php
						if(is_array($pvOthDrList)){
					?>
							<ul class="list-group">
					<?php
							foreach($pvOthDrList as $pvOthDr){
					?>
								<li class="list-group-item">
									<a href="<?php echo base_url()?>transactions/Bookings/view/<?php echo $pvOthDr['bookingId'];?>" class="" title="View" target="_blank">
										<?php echo date('d-m-Y',strtotime($pvOthDr['consultationDate']));?>
									</a>
								</li>
					<?php
							}
					?>
							</ul>
					<?php
						}else{
							echo "No Previous Visits";
						}
					?>
				</div>
			</div>
		</div>
	</div>
</div>